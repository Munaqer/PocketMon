
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
  * Mustafa
  * To change this template file, choose Tools | Templates
  * and open the template in the editor.
 */
public class GameObject {

    int cX;
    int cY;
    BufferedImage img = null;
    
    GameObject(int x, int y, String l) {
        this.cX = x;
        this.cY = y;
        
        try {
            img = ImageIO.read(new File(l));
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

    //does the actual drawing
    public void drawChar(Graphics g) {
        ImageObserver observer;

        g.drawImage(img, cX, cY, null);
        
    }
    
    public void changeImg(String l) {
        try {
            img = ImageIO.read(new File(l));
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
    
    public void move(int x, int y){
        this.cX = x;
        this.cY = y;
    }

}
