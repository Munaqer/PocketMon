/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import javax.swing.Timer;

public class Game extends Canvas implements Runnable {

    private boolean running = false;//for checking if game has checks if game has started to run

    public static Graphics g2d;//graphical drawer

    //game component variables--------------------------------------------------
    int frame = 0;//frame counter
    int w = 0;//width to be determined
    int h = 0;//height to be determined

    boolean walking = false;
    
    //test variables
    int mX = 0;
    int mY = 0;

    public void run() {

        this.requestFocus();//Requests that this Component get the input focus, and that this Component's top-level ancestor become the focused Window.
        setPreferredSize(new Dimension(100, 25));
        ActionListener al = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                long t = System.currentTimeMillis();//current time
                //System.out.println(frame);
                frame++;
                render();
                long tPrint = System.currentTimeMillis() - t;//time past variable
                System.out.println(tPrint);

            }
        };
        Timer timer = new Timer(10, al);
        timer.start();

    }
    public int spdX = 0;
    public int spdY = 0;
    public String mainCharImg[] = new String[]{"src//Images//Main//StandUp.png", "src//Images//Main//StandDown.png" ,
                                               "src//Images//Main//StandLeft.png", "src//Images//Main//StandRight.png" };

    //-----Game Objects---------------------------------------------------------
    public GameObject grass = new GameObject(mX, mY, "src//Images//Maps//worldmap.png");
    public GameObject mainChar = new GameObject(300 - 10, 300 - 7, mainCharImg[1]);

    //draws onto the window
    private void render() {
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);//buffers drawing
            return;
        }

        //-----Drawing----------------------------------------------------------
        Graphics g = bs.getDrawGraphics();

        g.clearRect(0, 0, w, h);
        h = getHeight();
        w = getWidth();

        draw(g);

        //KeyInput k = new KeyInput();
        KeyListener k = new KeyListener() {
            
            public void keyTyped(KeyEvent e) {
                
            }
            
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_A) {
                    spdX=2;
                    spdY=0;
                }
                if (key == KeyEvent.VK_D) {
                    spdX=-2;
                    spdY=0;
                }
                if (key == KeyEvent.VK_W) {
                    spdY=2;
                    spdX=0;
                }
                if (key == KeyEvent.VK_S) {
                    spdY=-2;
                    spdX=0;
                }
            }
            
            public void keyReleased(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_A && spdX==2) {
                    spdX=0;
                }
                if (key == KeyEvent.VK_D && spdX==-2) {
                    spdX=0;
                }
                if (key == KeyEvent.VK_W && spdY==2) {
                    spdY=0;
                }
                if (key == KeyEvent.VK_S && spdY==-2) {
                    spdY=0;
                }
            }
        };
        this.addKeyListener(k);
        
        if (spdX < 0) {
           mainChar.changeImg(mainCharImg[3]);
        } else if (spdX > 0) {
           mainChar.changeImg(mainCharImg[2]);
        }
        if (spdY > 0) {
           mainChar.changeImg(mainCharImg[0]);
        } else if (spdY < 0) {
           mainChar.changeImg(mainCharImg[1]);
        }

        //-----End--------------------------------------------------------------
        g.dispose();
        bs.show();

    }

    private void draw(Graphics g) {
        
        mX+=spdX;
        mY+=spdY;
        
        grass.move(mX, mY);
        grass.drawChar(g);
        
        mainChar.drawChar(g);
    }
}
